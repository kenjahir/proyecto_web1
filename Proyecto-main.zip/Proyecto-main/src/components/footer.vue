<script setup>

</script>
<template>
      <p>Todos los derechos reservados 2024</p>
</template>
<style>

</style>